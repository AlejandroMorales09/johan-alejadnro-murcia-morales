#include <windows.h>
#include<iostream>
#include <stdio.h>
#include <wchar.h>
#include <locale.h>
#include <stdlib.h>
using namespace std;



main()
{

    setlocale(LC_ALL, "");
using namespace std;


{

char mensaje  []={'P','R','O','G','R','A','M','A','C','I','�','N',' ','D','E',' ','S','O','F','T','W','A','R','e'};cout<<" \n\n\n\n\n\n\n\n\n\n\n\n   \t\t\t";
for (int i=0;i<=25;i++)
{
cout<<mensaje[i];
	Sleep (80);
}
cout<<"\n\n\n\n\n\n\n\n\n\n\n\n    				finalizado \n\n\n\n\n\n \n\n\n \n\n\n \n\n\n \n\n\n \n\n\n ";
}
}
