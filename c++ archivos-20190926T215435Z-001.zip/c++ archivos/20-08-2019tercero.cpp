#include <iostream>
using namespace std;
main ()
{
	
	int n1,n2;
		cout<<"\n programa para analizar numero e imprimirlo";
		cout<<"\n ingrese el primer numero ";
		cin>>n1;
		if (n1%2 ==0)
			{
				cout<<"el numero;"<<n1<<"es por";
			}
			else
			{
				cout<<"el numero:"<<n1<<"es impar";
			}
	
}
