#include <iostream>

using namespace std;
main ()
/*{

int contador;
 contador=0;
do
{
	cout<<"\n buen dia";
	contador = contador+1;

}
while (contador<=3);
}*/

{
	int contador;
	contador=0;
		while (contador<=3)
		{
			cout<<"\n buen dia se�or";
			contador=contador+1;
		}
cout <<"usted esta en:"<<contador;

}
