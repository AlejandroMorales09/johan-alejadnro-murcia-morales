#include<iostream>
//#include<cstdlib>
#include<conio.h>
using namespace std;
main()
{
int numero1,numero2,suma,n1,n2,resta,multiplicacion,m1,m2,division,d1,d2;	
	cout<<"buenas tardes \n\n\n\n";
	cout<<endl;
	cout<<"son mas de las 15 horas";
	cout<<"es hora de sumar \n\n";
		cout<<"\n\n\n hora de pedir datos\n";
	
		cout<<"ingrese el primer numero de la suma\n\n"; 
		   cin>>numero1;
		cout<"ingrese el segundo numero de la suma\n\n";
		   cin>>numero2;
		 suma=numero1+numero2;
		 cout<<"\n\n la suma es:"<<suma;
		 cout<<"\n\n es hora de pedir datos\n";
		 cout<<"\n\n ingrese el primer numero de la resta\n\n";
		 cin>>n1;
		 cout<<"\n\n ingrese el segundo numero de la resta\n\n";
		 cin>>n2;
		 	 resta=n1-n2;
		 cout<<"\n\n el resultado de la resta es"<<resta;
		 cout<<"\n\n\n ingrese el primer dato de multiplicacion\n\n";
		cin>>m2;
		cout<<"\n\ningrese el segundo dato de multiplicacion\n\n";
		cin>>m1	 ;
		 	multiplicacion=m2*m1;
		 cout<<"\n\n el resultado de multiplicacion es:"<<multiplicacion;
		 cout<<"\n\n ingrese el primer numero de la division\n\n";
		 cin>>d1;
		 cout<<"\n\n ingrese el segundo numero de la division\n\n ";
		 cin>>d2;
		 	division=d1/d2;
		 cout<<"\n\nnel resultado de division es:\n\n"<<division;	
		  	system ("pause");
		getch();  	
		
}
