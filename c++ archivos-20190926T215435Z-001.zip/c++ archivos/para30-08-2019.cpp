
									//EJERCICIO  DE PARA//

#include <iostream>
using namespace std;
main ()
/*{
	int i;

	//para	//desde	hasta	haga//
	for 	(i==1;	i<=5;	i++)
	{
		cout<<"hola norathor \n";
	}
}*/



/*{
	int coco;
	cin>>coco;
	for (coco==1;coco<7;coco++
	
	)
	

		{
			cout<<"buena tarde \n";
		
		}
}*/


//NUMEROS DEL 1 AL 6//
/*{
	int coco;
	for (coco==1;coco<7;coco++)
	{
		cout<<coco<<"\n";
		cout<<"\n";
		cout<<endl;
	}
	}*/
	
//NUMEROS DEL 6 AL 1//
	
	{
	int coco;
	for (coco=6;coco>0;coco--)
	{
		cout<<coco<<"\n";
		cout<<"\n";
		cout<<endl;
	}
	}
	
	
	
