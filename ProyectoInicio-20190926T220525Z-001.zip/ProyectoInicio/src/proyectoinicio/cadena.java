
package proyectoinicio;
import java.util.Scanner;

public class cadena {
    
     public static void main (String[]args)
     {
     Scanner raios= new Scanner(System.in);
             String nombre,apellido;
              System.out.println ("aplicativo para ingresar tus nombres y apellidos \n\n");
              System.out.println ("------ingresa tu nombre-------");
              nombre = raios.nextLine();
              System.out.println ("------ingresa tu apellido------");
              apellido = raios.nextLine();
              System.out.println ("---tu nombre es:---\n\n\t\t" +nombre+"\n ---y tu apellido es:\n\n\t\t"+apellido);
              
     }
}
