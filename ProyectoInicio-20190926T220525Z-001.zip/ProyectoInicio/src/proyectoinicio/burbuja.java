
package proyectoinicio;
import java.util.Scanner;

public class burbuja {
    public static void main (String [] args)
        
    {
        int i,cd ,j,fila,columna,auxiliar;
        int vector []=new int [50];
        Scanner entrada =new Scanner (System.in);
            System.out.println("digite");
            
            cd=entrada.nextInt();
            
            for (i=1;i<=cd;i++)
                    {
                        System.out.println("\n ingrese el numero del indice vector"+i);
                        vector[1]=entrada.nextInt();
                    }
                    for (fila=1;fila<=cd-1;fila++)
                    {
                        for (columna=1;columna<=cd-1;columna++)
                        {
                            if (vector [columna]>vector[columna+1])
                            {
                                auxiliar=vector[columna];
                                vector [columna]=vector [columna+1];
                                vector [columna+1]=auxiliar;
                            }
                        }
                    }
                        System.out.println ("\n ascendente");
                        
                                for (i=1;i<=cd;i++)
                                
                                {
                                    System.out.println(" "+vector[i]);
                                    
                                }
                                System.out.println ("\n descendente");
                                    for (i=cd;i>1;i--)
                                {
                                    System.out.println ("   "+vector[i]);
                                }
                                    System.out.println("\n");
    }
    
}
