
package proyectoinicio;

import java.util.Scanner;
public class breakkk {
    public static void main (String [] args){
        int opcion;
        System.out.println ("ingrese la opcion \n");
            Scanner Entrada= new Scanner (System.in);
         opcion = Entrada.nextInt();
                    switch (opcion)
                    {
                        case 1:
                            System.out.println("estoy en uno");
                        break;    
                        
                        
                        case 4  :
                            System.out.println ("estoy en cuatro");
                        break;
                        
                        
                        case 3 :
                            System.out.println("estoy en tres");
                        break;
                        
                        case 2 :
                        case 5 :
                            System.out.println ("Estoy en dos o cinco");
                            
                        break ;
                        
                        default :
                            System.out.println ("no estoy en nada");
                            
                            break;
                            
                    }
    }
    
}
