
package proyectoinicio;


public class dosenuno {
    
    
     public static void main (String[]args)
   
     
             ///CARACTER///
     /*
     {
         char calzon;
         calzon = ' ';
         System.out.println ("digite el caracter");
                 Scanner xd = new Scanner (System.in);
                 calzon = xd.next (). charAt(0);
                 System.out.println (" su caracter es:"+calzon);
     }*/
                ///CADENA///
    {
         String palabra1="el fin de semana \n";
                String palabra2="como helado";
                System.out.println(palabra1+palabra2);
     }
}