
package proyectoinicio;

import java.util.Scanner;
public class mtriz2 {
    public static void main(String[] args){
            Scanner entrada=new Scanner (System.in);
    
    

		int cd [  ] [  ] = new int [5] [5];
                
                    int a = 0;
                    
		
                        
                            
                       
	
			for (int i=0;i<4;i++)
			{
				for (int j=0;j<4;j++)
				{
					System.out.println ("digite un numero ["+i+"]["+j+"] \n");
					cd [ i ][ j ]=  entrada.nextInt();
				}
			}

					System.out.println ("imprimiendo.. :");
				for (int i=0;i<4;i++)
				{
					
					for (int j=0;j<4;j++)
			
				{
					System.out.print("["+i+"]["+j+"] \n");
                                         System.out.print  (cd [i][j]+"\n");
					}	
					System.out.print (i);
				}
					
				System.out.println ("take a damn answer bitch \n ");
				
				
				
				for (int i=0;i<4;i++)
				{
					System.out.println ("----------\n");
					for (int j=0;j<4;j++)
					{
					
						if (cd[i][j]<10)
					
					{
						System.out.print(cd [i][j]);
						System.out.print	("  ¦");
		
							
					}
					else
					{
					System.out.print (cd [i][j]);
					System.out.print("¦");

							
							
					}
					}
					
				
                                
				System.out.print ("\n");
				System.out.print("\n --------- \n");
                                System.out.println("presione 5 para ver");
                                a= entrada.nextInt();
                                }
                 
    if (a<5)
    {
        	for (int i=0;i<4;i++)
				{
					System.out.println ("----------\n");
					for (int j=0;j<4;j++)
					{
					
						if (cd[i][j]<10)
					
					{
						System.out.print(cd [i][j]);
						System.out.print	("  ¦");
		
							
					}
					else
					{
					System.out.print (cd [i][j]);
					System.out.print("¦");

							
							
					}
					}
				}	
				
                                
				System.out.print ("\n");
				System.out.print("\n --------- \n");
    }                            
                               
    
    else
    {
        	for (int i=0;i<4;i++)
				{
					System.out.println ("----------\n");
					for (int j=0;j<4;j++)
					{
					
						if (cd[i][j]<10)
					
					{
						System.out.print(cd [i][j]);
						System.out.print	("  ¦");
		
							
					}
					else
					{
					System.out.print (cd [i][j]);
					System.out.print("¦");

							
							
					}
					}
					
				}
				System.out.print ("\n");
				System.out.print("\n --------- \n");
                                }
    
    
			
    

}