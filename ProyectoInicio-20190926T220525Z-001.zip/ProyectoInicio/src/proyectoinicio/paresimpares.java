
package proyectoinicio;

import java.util.Scanner;
public class paresimpares {
    
        public static void main (String[]args)
        {
            int a,b=0,c=1;
            Scanner perra=new Scanner (System.in);
                  System.out.println ("ingrese un numero del 1 al 20");
                  a = perra.nextInt ();
                  if (a>21)
                      
                  {
                      
                    
                  while (b<=20)
                            {
                                System.out.println("se imprimiran los numeros pares");

                                
                                System.out.println (b);
                                b=b+2;
                            }  
                   }
                  else 
                  {
                      while (c<10)
                      {
                       
                          System.out.println(c);
                          c=c+2;
                                  
                      }
                  }
        }        
                
}
