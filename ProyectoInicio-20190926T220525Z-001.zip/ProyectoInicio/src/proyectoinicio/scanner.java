
package proyectoinicio;
import java.util.Scanner;
public class scanner {
    

   
        public static void main (String[]args)

    {
        int a,b=0,c=1;
        Scanner pichon=new Scanner (System.in);

            int n1=pichon.nextInt();

            int n2=pichon.nextInt();
        
             while (n2<=n1)
                 
      {
                System.out.println("error el segundo numero tiene que ser mayor que el primero");
                while (b<=20)
                            {
                                System.out.println("se imprimiran los numeros pares");

                                
                                System.out.println (b);
                                b=b+2;
                            } 
                n2=pichon.nextInt();
      }
             while (n1<=n2)
                 
      {
          while (c<10)
                      {
                       
                          System.out.println(c);
                          c=c+2;
                                  
                      }
          System.out.println(n1<=n2);
          n1++;
      }
    
            
            
    }
}